
package excepciones_ej2;

import java.lang.reflect.Array;


public class ClaseVector {
    
    protected int[] array=new int[5];

    public ClaseVector() {
    }

    public int[] getArray() {
        return array;
    }

    public void setArray(int[] array) {
        this.array = array;
    }
    
    
    
}
